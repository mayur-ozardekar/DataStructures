package com.casestudy.recipes.utility;

import com.casestudy.recipes.dto.AddRecipeRequest;
import com.casestudy.recipes.dto.IngredientsRequest;
import com.casestudy.recipes.dto.UpdateRecipeRequest;
import com.casestudy.recipes.entity.Ingredient;
import com.casestudy.recipes.entity.Instruction;
import com.casestudy.recipes.entity.Recipe;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class RecipeUtility {
    public static Recipe mapAddRecipeRequestToRecipe(AddRecipeRequest addRecipeRequest) {
        Recipe recipe = new Recipe();

        List<Ingredient> ingredientSet = addRecipeRequest.getIngredients()
                .stream()
                .filter(IngredientsRequest::isInclude)
                .map(ingredientsRequest -> {
                    Ingredient ingredient = new Ingredient();
                    ingredient.setRecipeIngredient(ingredientsRequest.getIngredient());
                    return ingredient;
                })
                .collect(Collectors.toList());

        recipe.setIngredients(ingredientSet);

        Instruction instruction = new Instruction();
        instruction.setRecipeInstructions(addRecipeRequest.getInstruction());
        recipe.setInstruction(instruction);

        recipe.setServings(addRecipeRequest.getServings());
        recipe.setTypeOfDish(addRecipeRequest.getTypeOfDish());

        return recipe;
    }

    public static Recipe mapUpdateRecipeRequestToRecipe(Recipe recipeExisting, UpdateRecipeRequest updateRecipeRequest) {

        if(!Objects.isNull(updateRecipeRequest.getName())) {
            recipeExisting.setName(updateRecipeRequest.getName());
        }

        if(!Objects.isNull(updateRecipeRequest.getServings())) {
            recipeExisting.setServings(updateRecipeRequest.getServings());
        }

        if(!Objects.isNull(updateRecipeRequest.getTypeOfDish())) {
            recipeExisting.setTypeOfDish(updateRecipeRequest.getTypeOfDish());
        }

        if(!Objects.isNull(updateRecipeRequest.getInstructions())){
            Instruction existingInstruction = recipeExisting.getInstruction();
            existingInstruction.setRecipeInstructions(updateRecipeRequest.getInstructions());
            recipeExisting.setInstruction(existingInstruction);
        }

        if(!Objects.isNull(updateRecipeRequest.getIngredients())){
            List<Ingredient> ingredientsExisting = recipeExisting.getIngredients();
            Set<Ingredient> ingredientsSet = updateRecipeRequest.getIngredients()
                    .stream()
                    .filter(IngredientsRequest::isInclude)
                    .map(ingredientsRequest -> {
                        Ingredient ingredient = new Ingredient();
                        ingredient.setRecipeIngredient(ingredientsRequest.getIngredient());
                        return ingredient;
                    })
                    .collect(Collectors.toSet());

            ingredientsExisting.addAll(ingredientsSet);

            recipeExisting.setIngredients(ingredientsExisting);
        }

        return recipeExisting;
    }
}
