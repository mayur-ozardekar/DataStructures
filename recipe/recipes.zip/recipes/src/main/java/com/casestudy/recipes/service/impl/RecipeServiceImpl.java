package com.casestudy.recipes.service.impl;

import com.casestudy.recipes.dto.AddRecipeRequest;
import com.casestudy.recipes.dto.FetchRecipeRequest;
import com.casestudy.recipes.dto.IngredientsRequest;
import com.casestudy.recipes.dto.UpdateRecipeRequest;
import com.casestudy.recipes.entity.Ingredient;
import com.casestudy.recipes.entity.Recipe;
import com.casestudy.recipes.enums.TypeOfDish;
import com.casestudy.recipes.exceptions.RecipeNotFoundException;
import com.casestudy.recipes.repository.RecipeRepository;
import com.casestudy.recipes.service.RecipeService;
import com.casestudy.recipes.utility.RecipeUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class RecipeServiceImpl implements RecipeService {

    private final RecipeRepository recipeRepository;

    @Override
    public List<Recipe> findRecipesBasedOnCriteria(FetchRecipeRequest fetchRecipeRequest) {
        Integer servings = fetchRecipeRequest.getServings();
        TypeOfDish typeOfDish = fetchRecipeRequest.getTypeOfDish();
        String instruction = fetchRecipeRequest.getInstruction();
        List<IngredientsRequest> ingredients = fetchRecipeRequest.getIngredients();

        Set<String> includedIngredients = ingredients.stream()
                .filter(IngredientsRequest::isInclude)
                .map(IngredientsRequest::getIngredient)
                .collect(Collectors.toSet());

        Set<String> excludedIngredients = ingredients.stream()
                .filter(ingredientsRequest -> !ingredientsRequest.isInclude())
                .map(IngredientsRequest::getIngredient)
                .collect(Collectors.toSet());

        return recipeRepository.finaAllRecipesByCriteria(typeOfDish, servings, includedIngredients, excludedIngredients, instruction);
    }

    @Override
    public void deleteRecipe(Long id) {
        recipeRepository.deleteById(id);
    }

    @Override
    public Recipe addRecipe(AddRecipeRequest addRecipeRequest) {
        Recipe recipe = RecipeUtility.mapAddRecipeRequestToRecipe(addRecipeRequest);
        return recipeRepository.save(recipe);
    }

    @Override
    public Recipe updateRecipe(Long id, UpdateRecipeRequest updateRecipeRequest) {

        Recipe recipeExisting = recipeRepository.findById(id)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found for RecipeId : " + id));

        Recipe recipeUpdated = RecipeUtility.mapUpdateRecipeRequestToRecipe(recipeExisting, updateRecipeRequest);

        return recipeRepository.save(recipeUpdated);
    }

    @Override
    public List<Recipe> findAllRecipes() {
        return recipeRepository.findAll();
    }
}
