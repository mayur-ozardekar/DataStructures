package com.casestudy.recipes.dto;

import com.casestudy.recipes.enums.TypeOfDish;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateRecipeRequest {

    private String name;
    private Integer servings;
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
    private TypeOfDish typeOfDish;
    private String instructions;
    private List<IngredientsRequest> ingredients;

}
