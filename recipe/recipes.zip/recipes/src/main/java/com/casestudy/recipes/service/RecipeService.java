package com.casestudy.recipes.service;

import com.casestudy.recipes.dto.AddRecipeRequest;
import com.casestudy.recipes.dto.FetchRecipeRequest;
import com.casestudy.recipes.dto.UpdateRecipeRequest;
import com.casestudy.recipes.entity.Recipe;

import java.util.List;

public interface RecipeService {

    Recipe addRecipe(AddRecipeRequest addRecipeRequest);

    Recipe updateRecipe(Long id, UpdateRecipeRequest updateRecipeRequest);

    List<Recipe> findAllRecipes();

    List<Recipe> findRecipesBasedOnCriteria(FetchRecipeRequest fetchRecipeRequest);

    void deleteRecipe(Long id);

}
