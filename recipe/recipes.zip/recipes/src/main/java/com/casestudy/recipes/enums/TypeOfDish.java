package com.casestudy.recipes.enums;

public enum TypeOfDish {
    VEGETARIAN, NONVEGETARIAN
}
