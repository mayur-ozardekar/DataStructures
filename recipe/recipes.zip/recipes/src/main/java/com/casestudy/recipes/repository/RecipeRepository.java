package com.casestudy.recipes.repository;

import com.casestudy.recipes.entity.Recipe;
import com.casestudy.recipes.enums.TypeOfDish;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Long> {

    @Query(value = "FROM Recipe R\n" +
            "JOIN Ingredient ING\n" +
            "ON ING.recipe.id = R.id\n" +
            "JOIN Instruction INS\n" +
            "ON INS.recipe.id = R.id\n" +
            "WHERE R.typeOfDish = :typeOfDish \n" +
            "AND R.servings = :servings\n" +
            "AND ING.recipeIngredient IN :inclusiveIngredients \n" +
            "AND ING.recipeIngredient NOT IN :exclusiveIngredients \n" +
            "AND LOWER(INS.recipeInstructions) LIKE CONCAT('%', LOWER(:instruction), '%')\n")
    List<Recipe> finaAllRecipesByCriteria(
            @Param("typeOfDish") TypeOfDish typeOfDish,
            @Param("servings") Integer servings,
            @Param("inclusiveIngredients") Set<String> inclusiveIngredients,
            @Param("exclusiveIngredients") Set<String> exclusiveIngredients,
            @Param("instruction") String instruction);
}
