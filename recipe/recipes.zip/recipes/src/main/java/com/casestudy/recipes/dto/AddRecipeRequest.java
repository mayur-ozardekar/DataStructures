package com.casestudy.recipes.dto;

import com.casestudy.recipes.enums.TypeOfDish;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddRecipeRequest {

    @NotBlank(message = "The field 'name' is required")
    private String name;
    @NotNull(message = "The field 'servings'' is required")
    private Integer servings;
    @NotNull(message = "The field 'typeOfDish' is required")
    @JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
    private TypeOfDish typeOfDish;
    @NotBlank(message = "The field 'instruction' is required")
    private String instruction;
    @Valid
    @NotEmpty(message = "The field 'ingredients' is required")
    private List<IngredientsRequest> ingredients;

}
