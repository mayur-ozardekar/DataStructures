package com.casestudy.recipes.controller;

import com.casestudy.recipes.exceptions.ErrorResponse;
import com.casestudy.recipes.exceptions.RecipeNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class RecipeExceptionAdvice extends ResponseEntityExceptionHandler {

    @ExceptionHandler({RecipeNotFoundException.class})
    public ResponseEntity<ErrorResponse> notFoundException(RecipeNotFoundException ex) {
        if (log.isErrorEnabled()) {
            log.error("Not found Exception: " + ex.getMessage(), ex);
        }
        ErrorResponse errorResponse = new ErrorResponse("404", ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.EXPECTATION_FAILED);
    }

    @ExceptionHandler({Throwable.class})
    public ResponseEntity<Object> handleException(Throwable ex) {
        if (log.isErrorEnabled()) {
            log.error("Unknown exception: " + ex.getMessage(), ex);
        }
        ErrorResponse errorResponse = new ErrorResponse("500", ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                       HttpHeaders headers,
                                                       HttpStatus status, WebRequest request) {
        if (log.isErrorEnabled()) {
            log.error("Method Argument Not Valid Exception: " + ex.getMessage(), ex);
        }
        String errorMessage = this.formatError(ex.getBindingResult().getAllErrors());
        return new ResponseEntity<>(new ErrorResponse("400", errorMessage), HttpStatus.BAD_REQUEST);
    }

    private String formatError(List<ObjectError> allErrors) {
        return allErrors.stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(Collectors.joining(","));
    }
}
