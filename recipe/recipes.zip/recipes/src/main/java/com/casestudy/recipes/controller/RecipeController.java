package com.casestudy.recipes.controller;

import com.casestudy.recipes.dto.AddRecipeRequest;
import com.casestudy.recipes.dto.FetchRecipeRequest;
import com.casestudy.recipes.dto.UpdateRecipeRequest;
import com.casestudy.recipes.entity.Recipe;
import com.casestudy.recipes.service.RecipeService;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v1/")
public class RecipeController {

    private final RecipeService recipeService;

    @GetMapping(value = "hello")
    public ResponseEntity<String> sayHello() {
        return ResponseEntity.ok("Hello ABN Recipes !!!");
    }

    @PostMapping(value = "recipes",
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Long> addRecipe(@Valid @RequestBody AddRecipeRequest addRecipeRequest) {
        Recipe recipe = recipeService.addRecipe(addRecipeRequest);
        return ResponseEntity.created(URI.create("/recipes/" + recipe.getId())).body(recipe.getId());
    }

    @PutMapping(value = "recipes/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Long> updateRecipe(@PathVariable Long id, @Valid @RequestBody UpdateRecipeRequest updateRecipeRequest) {
        Recipe recipeUpdated = recipeService.updateRecipe(id, updateRecipeRequest);
        return ResponseEntity.ok(recipeUpdated.getId());
    }

    @PostMapping(value = "fetchRecipes",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Recipe>> getRecipesBasedOnCriteria(@RequestBody FetchRecipeRequest fetchRecipeRequest) {
        List<Recipe> recipes = recipeService.findRecipesBasedOnCriteria(fetchRecipeRequest);
        return ResponseEntity.ok(recipes);
    }

    @GetMapping(value = "recipes")
    public ResponseEntity<List<Recipe>> getRecipes() {
        List<Recipe> recipes = recipeService.findAllRecipes();
        return ResponseEntity.ok(recipes);
    }

    @DeleteMapping(value = "recipes/{id}")
    public ResponseEntity<Void> deleteRecipes(@PathVariable Long id) {
        recipeService.deleteRecipe(id);
        return ResponseEntity.noContent().build();
    }
}
