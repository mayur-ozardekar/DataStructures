INSERT INTO recipe (id, name, servings, type_of_dish) VALUES (1, 'Pasta', 4, 'NONVEGETARIAN');

INSERT INTO instruction (id, recipe_id, recipe_instructions) VALUES (1, 1, 'Boil water and then put salt in water. Later add paste and let it boil for 20 minutes. At the end, add salmon in it');
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (1, 'pasta', 1);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (2, 'salt', 1);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (3, 'salmon', 1);

INSERT INTO recipe (id, name, servings, type_of_dish) VALUES (2, 'Indian lentil', 4, 'VEGETARIAN');

INSERT INTO instruction (id, recipe_id, recipe_instructions) VALUES (2, 2, 'Boil the lentil. Make the fried paste of onion and tomato. Add salt, chilly powder and then add turmeric powder in it. Later put the boiled dal in the paste and heat it for few minutes');
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (4, 'onion', 2);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (5, 'tomato', 2);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (6, 'salt', 2);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (7, 'chilli', 2);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (8, 'turmeric', 2);

INSERT INTO recipe (id, name, servings, type_of_dish) VALUES (3, 'Fried rice', 4, 'VEGETARIAN');

INSERT INTO instruction (id, recipe_id, recipe_instructions) VALUES (3, 3, 'Boil the rice. Cut the carrot, beans, onion and cabbage and then fry in pan. Add the spicy sauce in mixture and after 5 minutes add the rice. Mix everything and heat for 15 minutes');
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (9, 'onion', 3);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (10, 'carrot', 3);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (11, 'beans', 3);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (12, 'cabbage', 3);
INSERT INTO ingredient (id, recipe_ingredient, recipe_id) VALUES (13, 'spicy sauce', 3);