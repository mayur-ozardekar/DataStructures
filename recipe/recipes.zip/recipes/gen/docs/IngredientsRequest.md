

# IngredientsRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredient** | **String** |  |  [optional]
**include** | **Boolean** |  |  [optional]



