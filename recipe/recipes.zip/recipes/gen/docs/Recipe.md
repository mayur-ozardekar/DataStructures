

# Recipe

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**name** | **String** |  |  [optional]
**servings** | **Integer** |  |  [optional]
**typeOfDish** | [**TypeOfDishEnum**](#TypeOfDishEnum) |  |  [optional]
**instruction** | [**Instruction**](Instruction.md) |  |  [optional]
**ingredients** | [**Set&lt;Ingredient&gt;**](Ingredient.md) |  |  [optional]



## Enum: TypeOfDishEnum

Name | Value
---- | -----
VEGETARIAN | &quot;VEGETARIAN&quot;
NONVEGETARIAN | &quot;NONVEGETARIAN&quot;



