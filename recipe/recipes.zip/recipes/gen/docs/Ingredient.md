

# Ingredient

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**ingredients** | **String** |  |  [optional]



