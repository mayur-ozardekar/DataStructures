

# UpdateRecipeRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**servings** | **Integer** |  |  [optional]
**typeOfDish** | [**TypeOfDishEnum**](#TypeOfDishEnum) |  |  [optional]
**instructions** | **String** |  |  [optional]
**ingredients** | [**List&lt;IngredientsRequest&gt;**](IngredientsRequest.md) |  |  [optional]



## Enum: TypeOfDishEnum

Name | Value
---- | -----
VEGETARIAN | &quot;VEGETARIAN&quot;
NONVEGETARIAN | &quot;NONVEGETARIAN&quot;



