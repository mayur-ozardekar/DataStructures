

# FetchRecipeRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servings** | **Integer** |  |  [optional]
**typeOfDish** | [**TypeOfDishEnum**](#TypeOfDishEnum) |  |  [optional]
**instruction** | **String** |  |  [optional]
**ingredients** | [**List&lt;IngredientsRequest&gt;**](IngredientsRequest.md) |  |  [optional]



## Enum: TypeOfDishEnum

Name | Value
---- | -----
VEG | &quot;VEG&quot;
NONVEG | &quot;NONVEG&quot;



