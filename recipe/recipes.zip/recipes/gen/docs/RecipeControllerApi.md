# RecipeControllerApi

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addRecipe**](RecipeControllerApi.md#addRecipe) | **POST** /api/v1/recipes | 
[**deleteRecipes**](RecipeControllerApi.md#deleteRecipes) | **DELETE** /api/v1/recipes/{id} | 
[**getRecipes1**](RecipeControllerApi.md#getRecipes1) | **GET** /api/v1/recipes | 
[**sayHello**](RecipeControllerApi.md#sayHello) | **GET** /api/v1/hello | 
[**updateRecipe**](RecipeControllerApi.md#updateRecipe) | **PUT** /api/v1/recipes/{id} | 


<a name="addRecipe"></a>
# **addRecipe**
> Long addRecipe(addRecipeRequest)



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.RecipeControllerApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost:8080");

    RecipeControllerApi apiInstance = new RecipeControllerApi(defaultClient);
    AddRecipeRequest addRecipeRequest = new AddRecipeRequest(); // AddRecipeRequest | 
    try {
      Long result = apiInstance.addRecipe(addRecipeRequest);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling RecipeControllerApi#addRecipe");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **addRecipeRequest** | [**AddRecipeRequest**](AddRecipeRequest.md)|  |

### Return type

**Long**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

<a name="deleteRecipes"></a>
# **deleteRecipes**
> deleteRecipes(id)



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.RecipeControllerApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost:8080");

    RecipeControllerApi apiInstance = new RecipeControllerApi(defaultClient);
    Long id = 56L; // Long | 
    try {
      apiInstance.deleteRecipes(id);
    } catch (ApiException e) {
      System.err.println("Exception when calling RecipeControllerApi#deleteRecipes");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Long**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

<a name="getRecipes1"></a>
# **getRecipes1**
> List&lt;Recipe&gt; getRecipes1(fetchRecipeRequest, count, pageId)



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.RecipeControllerApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost:8080");

    RecipeControllerApi apiInstance = new RecipeControllerApi(defaultClient);
    FetchRecipeRequest fetchRecipeRequest = new FetchRecipeRequest(); // FetchRecipeRequest | 
    Integer count = 10; // Integer | 
    Integer pageId = 1; // Integer | 
    try {
      List<Recipe> result = apiInstance.getRecipes1(fetchRecipeRequest, count, pageId);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling RecipeControllerApi#getRecipes1");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **fetchRecipeRequest** | [**FetchRecipeRequest**](.md)|  |
 **count** | **Integer**|  | [optional] [default to 10]
 **pageId** | **Integer**|  | [optional] [default to 1]

### Return type

[**List&lt;Recipe&gt;**](Recipe.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*, application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

<a name="sayHello"></a>
# **sayHello**
> String sayHello()



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.RecipeControllerApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost:8080");

    RecipeControllerApi apiInstance = new RecipeControllerApi(defaultClient);
    try {
      String result = apiInstance.sayHello();
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling RecipeControllerApi#sayHello");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

<a name="updateRecipe"></a>
# **updateRecipe**
> Long updateRecipe(id, updateRecipeRequest)



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.RecipeControllerApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost:8080");

    RecipeControllerApi apiInstance = new RecipeControllerApi(defaultClient);
    Long id = 56L; // Long | 
    UpdateRecipeRequest updateRecipeRequest = new UpdateRecipeRequest(); // UpdateRecipeRequest | 
    try {
      Long result = apiInstance.updateRecipe(id, updateRecipeRequest);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling RecipeControllerApi#updateRecipe");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Long**|  |
 **updateRecipeRequest** | [**UpdateRecipeRequest**](UpdateRecipeRequest.md)|  |

### Return type

**Long**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | OK |  -  |

