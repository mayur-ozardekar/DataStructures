

# AddRecipeRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**servings** | **Integer** |  | 
**typeOfDish** | [**TypeOfDishEnum**](#TypeOfDishEnum) |  | 
**instruction** | **String** |  | 
**ingredients** | [**List&lt;IngredientsRequest&gt;**](IngredientsRequest.md) |  | 



## Enum: TypeOfDishEnum

Name | Value
---- | -----
VEGETARIAN | &quot;VEGETARIAN&quot;
NONVEGETARIAN | &quot;NONVEGETARIAN&quot;



